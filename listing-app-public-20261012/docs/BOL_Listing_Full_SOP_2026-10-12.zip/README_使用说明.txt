BOL 精品 Listing 全流程 SOP 文件

解压本 ZIP 到 Windows 桌面即可看到 BOL_Listing_Full_SOP_2026-10-12.md。
文档为执行手册，不会自动修改原主 SOP。
